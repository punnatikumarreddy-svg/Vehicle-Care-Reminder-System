<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

$config = require __DIR__ . '/config.php';
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin === $config['allowed_origin']) {
    header("Access-Control-Allow-Origin: $origin");
    header('Vary: Origin');
}
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

function reply($data, int $status=200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
function body(): array {
    $data = json_decode(file_get_contents('php://input'), true);
    return is_array($data) ? $data : [];
}
try {
    $pdo = new PDO(
        "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
        $config['db_user'], $config['db_pass'],
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]
    );
} catch (Throwable $e) {
    reply(['error'=>'Database connection failed. Check server database settings.'], 500);
}

$method = $_SERVER['REQUEST_METHOD'];
$path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$parts = explode('/', $path);
$resource = $_GET['resource'] ?? ($parts[count($parts)-1] ?? '');
$input = body();

function issueToken(PDO $pdo, int $userId): string {
    $token = bin2hex(random_bytes(32));
    $hash = hash('sha256', $token);
    $stmt = $pdo->prepare("INSERT INTO api_tokens(user_id,token_hash,expires_at) VALUES(?,?,DATE_ADD(NOW(), INTERVAL 30 DAY))");
    $stmt->execute([$userId,$hash]);
    return $token;
}
function currentUser(PDO $pdo): array {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!preg_match('/Bearer\s+([a-f0-9]{64})/i', $header, $m)) reply(['error'=>'Please sign in again.'],401);
    $stmt = $pdo->prepare("SELECT u.id,u.name,u.email FROM api_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=? AND t.expires_at>NOW()");
    $stmt->execute([hash('sha256',$m[1])]);
    $user = $stmt->fetch();
    if (!$user) reply(['error'=>'Session expired. Please sign in again.'],401);
    return $user;
}

if ($resource === 'register' && $method === 'POST') {
    $name = trim($input['name'] ?? '');
    $email = strtolower(trim($input['email'] ?? ''));
    $password = $input['password'] ?? '';
    if ($name==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<8)
        reply(['error'=>'Enter a name, valid email and password with at least 8 characters.'],422);
    try {
        $s=$pdo->prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)");
        $s->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]);
        $id=(int)$pdo->lastInsertId();
        reply(['token'=>issueToken($pdo,$id),'user'=>['id'=>$id,'name'=>$name,'email'=>$email]],201);
    } catch (PDOException $e) { reply(['error'=>'That email may already be registered.'],409); }
}
if ($resource === 'login' && $method === 'POST') {
    $s=$pdo->prepare("SELECT id,name,email,password_hash FROM users WHERE email=?");
    $s->execute([strtolower(trim($input['email'] ?? ''))]);
    $u=$s->fetch();
    if (!$u || !password_verify($input['password'] ?? '',$u['password_hash'])) reply(['error'=>'Incorrect email or password.'],401);
    reply(['token'=>issueToken($pdo,(int)$u['id']),'user'=>['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email']]]);
}

$user = currentUser($pdo);
$uid = (int)$user['id'];

if ($resource === 'me' && $method === 'GET') reply(['user'=>$user]);
if ($resource === 'logout' && $method === 'POST') {
    $h=$_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/Bearer\s+([a-f0-9]{64})/i',$h,$m)) {
        $s=$pdo->prepare("DELETE FROM api_tokens WHERE token_hash=?");
        $s->execute([hash('sha256',$m[1])]);
    }
    reply(['message'=>'Signed out']);
}

// Whitelisted tables and fields. Every query is scoped to the signed-in user.
$schemas = [
 'vehicles'=>['table'=>'vehicles','fields'=>['nickname','make','model','year','registration_number','fuel_type','odometer_km','vin']],
 'reminders'=>['table'=>'reminders','fields'=>['vehicle_id','title','description','due_date','due_odometer_km','status']],
 'services'=>['table'=>'service_records','fields'=>['vehicle_id','service_date','service_type','description','workshop','odometer_km','cost','next_service_date','next_service_km']],
 'fuel'=>['table'=>'fuel_records','fields'=>['vehicle_id','fuel_date','litres','price_per_litre','total_cost','odometer_km','station']],
 'expenses'=>['table'=>'expenses','fields'=>['vehicle_id','expense_date','category','description','amount']],
 'notifications'=>['table'=>'notifications','fields'=>['vehicle_id','reminder_id','message','is_read']]
];
if (!isset($schemas[$resource])) reply(['error'=>'Unknown API endpoint.'],404);
$schema=$schemas[$resource]; $table=$schema['table']; $fields=$schema['fields'];
$id=isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($method==='GET') {
    $sql="SELECT * FROM `$table` WHERE user_id=?";
    $args=[$uid];
    if ($id) { $sql.=" AND id=?"; $args[]=$id; }
    $sql.=" ORDER BY id DESC";
    $s=$pdo->prepare($sql); $s->execute($args);
    $rows=$s->fetchAll();
    reply($id ? ($rows[0] ?? null) : $rows);
}
if ($method==='POST' || $method==='PATCH') {
    $data=[];
    foreach ($fields as $f) if (array_key_exists($f,$input)) $data[$f]=$input[$f];
    if (!$data) reply(['error'=>'No valid fields supplied.'],422);
    if (isset($data['vehicle_id'])) {
        $v=$pdo->prepare("SELECT id FROM vehicles WHERE id=? AND user_id=?");
        $v->execute([(int)$data['vehicle_id'],$uid]);
        if (!$v->fetch()) reply(['error'=>'Vehicle not found for this account.'],403);
    }
    if ($method==='POST') {
        $cols=array_merge(['user_id'],array_keys($data));
        $vals=array_merge([$uid],array_values($data));
        $sql="INSERT INTO `$table` (`".implode('`,`',$cols)."`) VALUES (".implode(',',array_fill(0,count($cols),'?')).")";
        $s=$pdo->prepare($sql); $s->execute($vals);
        reply(['id'=>(int)$pdo->lastInsertId(),'message'=>'Created successfully'],201);
    }
    if (!$id) reply(['error'=>'Provide ?id= for update.'],422);
    $sets=implode(',',array_map(fn($f)=>"`$f`=?",array_keys($data)));
    $s=$pdo->prepare("UPDATE `$table` SET $sets WHERE id=? AND user_id=?");
    $s->execute(array_merge(array_values($data),[$id,$uid]));
    reply(['message'=>'Updated successfully']);
}
if ($method==='DELETE') {
    if (!$id) reply(['error'=>'Provide ?id= for delete.'],422);
    $s=$pdo->prepare("DELETE FROM `$table` WHERE id=? AND user_id=?");
    $s->execute([$id,$uid]);
    reply(['message'=>'Deleted successfully']);
}
reply(['error'=>'Method not allowed.'],405);
