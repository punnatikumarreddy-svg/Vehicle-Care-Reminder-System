<?php
// Copy this file to config.local.php and enter your hosting database details.
// Never upload real database passwords to a public Git repository.
return [
    'db_host' => getenv('DB_HOST') ?: 'localhost',
    'db_name' => getenv('DB_NAME') ?: 'drivecare_db',
    'db_user' => getenv('DB_USER') ?: 'YOUR_DB_USERNAME',
    'db_pass' => getenv('DB_PASS') ?: 'YOUR_DB_PASSWORD',
    'allowed_origin' => getenv('FRONTEND_ORIGIN') ?: 'https://tranquil-stroopwafel-79ce6a.netlify.app',
];
