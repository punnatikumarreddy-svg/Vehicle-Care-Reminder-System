// Add this file to your Netlify frontend and set API_BASE to your PHP hosting URL.
const API_BASE = "https://YOUR-PHP-HOST.example.com/api/index.php";

function getToken() {
  return localStorage.getItem("drivecare_token");
}

async function api(resource, { method = "GET", data = null, id = null } = {}) {
  const url = new URL(API_BASE);
  url.searchParams.set("resource", resource);
  if (id !== null) url.searchParams.set("id", id);

  const headers = { "Content-Type": "application/json" };
  if (getToken()) headers.Authorization = `Bearer ${getToken()}`;

  const response = await fetch(url, {
    method,
    headers,
    body: data ? JSON.stringify(data) : undefined
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Request failed");
  return result;
}

async function drivecareRegister(name, email, password) {
  const result = await api("register", { method: "POST", data: { name, email, password } });
  localStorage.setItem("drivecare_token", result.token);
  return result.user;
}
async function drivecareLogin(email, password) {
  const result = await api("login", { method: "POST", data: { email, password } });
  localStorage.setItem("drivecare_token", result.token);
  return result.user;
}
async function drivecareLogout() {
  try { await api("logout", { method: "POST" }); }
  finally { localStorage.removeItem("drivecare_token"); }
}
async function drivecareList(resource) { return api(resource); }
async function drivecareCreate(resource, data) { return api(resource, { method: "POST", data }); }
async function drivecareUpdate(resource, id, data) { return api(resource, { method: "PATCH", id, data }); }
async function drivecareDelete(resource, id) { return api(resource, { method: "DELETE", id }); }

// Example:
// const vehicles = await drivecareList("vehicles");
// await drivecareCreate("vehicles", {
//   make: "Toyota", model: "Innova", year: 2022,
//   registration_number: "KA01AB1234", fuel_type: "Diesel", odometer_km: 25000
// });
